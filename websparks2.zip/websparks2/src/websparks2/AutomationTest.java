package websparks2;

import java.util.Random;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.Keys;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class AutomationTest {
	static WebDriver driver;
	static WebElement element;
	static String parentWindowHandler, childWindowHandler;
	
	public static void main(String[] args) throws Exception {
	
		initDriver();
		signIn();
		addListItem(10); //add 10 items
		signOut();
		signInWithoutPwd();
		removeListItem (5,10); //remove items from 5th to 10th by looping 5 times
		signOut();
		
	}
	 public static String generateRandomString() {
	    int leftLimit = 97; // letter 'a'
	    int rightLimit = 122; // letter 'z'
	    int targetStringLength = 10;
	    Random random = new Random();
	
	    String generatedString = random.ints(leftLimit, rightLimit + 1)
	      .limit(targetStringLength)
	      .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
	      .toString();
	
	    return generatedString;
	}
	public static void initDriver() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\User\\Desktop\\ChromeDriver\\chromedriver.exe");
		driver = new ChromeDriver();
		
	}
	
	public static void signIn() throws Exception {
		//login Github
		driver.get("https://todo-list-login.firebaseapp.com/#!/home");
		driver.manage().window().maximize();
		Thread.sleep(10000);
		
		driver.findElement(By.xpath("(//a/span)[4]")).click();
		Thread.sleep(15000);
		
		//get parent window handler
		parentWindowHandler = driver.getWindowHandle();
		System.out.println(parentWindowHandler);
		
		//get child window handler
		Set<String> windowHandles = driver.getWindowHandles();
		Iterator<String> windowIterator = windowHandles.iterator();
		
		//System.out.println(windowHandles.isEmpty());
		//System.out.println(windowHandles.size());
		
		if (!windowHandles.isEmpty()) {
			windowIterator.next(); //skip the parent window
			childWindowHandler = windowIterator.next();
			System.out.println(childWindowHandler);
			driver.switchTo().window(childWindowHandler);
		}
		
		
		driver.findElement(By.xpath("//input[@id='login_field']")).sendKeys("tiongss");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("cz98hb25jd");
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//input[@type='submit' and @value='Sign in']")).click();
		Thread.sleep(1000);
		driver.close();
		
		driver.switchTo().window(parentWindowHandler);
		System.out.println(driver.getCurrentUrl());
		
		Thread.sleep(3000);
	}
	
	public static void signInWithoutPwd() throws Exception {
		driver.findElement(By.xpath("(//a/span)[4]")).click();
		Thread.sleep(5000);
	}
	
	public static void signOut() throws Exception {
		//driver.findElement(By.xpath("//button[text()='Sign out']")).click();
		driver.findElement(By.xpath("//button[@ng-click='home.signOut()']")).click();
		Thread.sleep(3000);		
	}
	
	public static void addListItem (int itemCount) throws Exception {
		//add list - loop for 10 times 
		for (int i = 1; i <= itemCount; i++) {
			String randomString = "#" + i + "-" + generateRandomString();
			System.out.println(randomString);
			
			// click add list button
			//element = driver.findElement(By.xpath("//button[text()='Add List']/parent::div/parent::div//input"));
			element = driver.findElement(By.xpath("//input[@type='text' and @ng-model='home.list']"));
			element.click();
			
			element.sendKeys(randomString);
			
			//click add list button
			driver.findElement(By.xpath("//button[text()='Add List']")).click();
			
			Thread.sleep(1200);
		}
	}
	
	public static void removeListItem (int startItemIndex, int lastItemIndex) throws Exception {
		int count = lastItemIndex - startItemIndex +1 ; //+1 to include last item to be removed
		
		for (int i = 1; i <= count; i++) {
			String delListBtnXpath = "(//a[@class='ng-binding']/following::div/button)[" + startItemIndex + "]";
			driver.findElement(By.xpath(delListBtnXpath)).click();
			Thread.sleep(1000);
		}
	}
}
